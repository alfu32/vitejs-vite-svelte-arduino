
#ifndef WIFI_SSID
#define WIFI_SSID "WiFi-2.4-DD88"
#endif
#ifndef WIFI_PASSWORD
#define WIFI_PASSWORD "ws2u4ua5w3rnf"
#endif